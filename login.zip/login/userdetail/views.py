from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from .models import userdetail
from userdetail.models import userdetail
 
def home(request):
     return render(request,"index.html")
def signin(request):
    data={}
    if request.method=="POST":
        user_id=request.POST.get('uid')
        Password=request.POST.get('pass')
        data=userdetail.objects.all()
        for a in data:
             if user_id==a.user_id and Password==a.Password:
                  fname=a.first_name
                  data={'fname':fname}
                  return render(request,'login.html',data)
    return render(request,"login.html") 

def  register(request):
        if request.method=="POST":
            first_name=request.POST.get('fname')
            last_name=request.POST.get('lname')
            user_id=request.POST.get('uid')
            assosciate_id=request.POST.get('aid') 
            email=request.POST.get('email')
            date=request.POST.get('date')
            Password=request.POST.get('pass')
            cpassword=request.POST.get('cpass')
            if cpassword!=Password:
                return render (request,'register.html',{"error":True})
            my_user=userdetail(first_name=first_name,last_name=last_name,user_id=user_id,assosciate_id=assosciate_id,email=email,date=date,Password=Password)
            my_user.save()
            print(first_name,last_name,user_id,assosciate_id,email,date,Password,cpassword)

        return render(request,"register.html") 
        
# Create your views here.
