from django.contrib import admin
from django.contrib.admin.sites import site
from userdetail.models import userdetail

# Register your models here.

class userAdmin(admin.ModelAdmin):
    listdisplay=('first_name','last_name','user_id','assosciate_id','email','date','Password')

admin.site.register(userdetail,userAdmin)
