from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class userdetail(models.Model):
    first_name=models.CharField(max_length=50)
    last_name=models.CharField(max_length=50)
    user_id=models.CharField(max_length=50)
    assosciate_id=models.CharField(max_length=50)
    email=models.EmailField(max_length=254)
    date=models.DateField(auto_now=False, auto_now_add=False)
    Password=models.CharField(max_length=50)


